Mazda 6 GH AS-BUILT STUDIO — reference UI asset extraction

Extracted from the supplied screenshot as visual references.

Recommended implementation:
- Do NOT build the whole screen as one bitmap.
- Use native Android layouts/components for tabs, rows, buttons, text and checkboxes.
- Use extracted logo/gauge/icons as image assets.
- Recreate red glow/borders with XML shape drawables or Compose modifiers so scaling stays sharp.
- Keep As-Built values as real selectable/editable text.
- Active tab/row: red gradient/glow; inactive: charcoal.
- Rounded corners approx. 10–16 dp.
- Main palette: near-black/charcoal + bright Mazda red + white/muted gray.

Important: screenshot crops include surrounding pixels/background and are intended as references.
For production, redraw icons/backgrounds as transparent/vector assets where possible.
